"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Play, Plus, Star, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getImageUrl, type Movie } from "@/lib/tmdb"
import { cn } from "@/lib/utils"

interface HeroCarouselProps {
  movies: Movie[]
  onPlay?: (movie: Movie) => void
}

export function HeroCarousel({ movies, onPlay }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % movies.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [movies.length, isAutoPlaying])

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + movies.length) % movies.length)
    setIsAutoPlaying(false)
  }

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % movies.length)
    setIsAutoPlaying(false)
  }

  if (!movies.length) return null

  const currentMovie = movies[currentIndex]

  return (
    <div className="relative w-full aspect-video overflow-hidden rounded-2xl hero-3d-slider">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src={getImageUrl(currentMovie.backdrop_path, "original") || "/placeholder.svg"}
          alt={currentMovie.title}
          fill
          className="object-cover"
          style={{
            filter: "saturate(1.2) contrast(1.3)",
          }}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex items-center">
        <div className="flex items-center justify-between w-full h-full p-6 md:p-8">
          {/* Left Content */}
          <div className="flex-1 max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <Badge className="bg-orange-500 text-white">New Movies</Badge>
              <div className="flex items-center gap-1 text-yellow-500">
                <Star className="w-4 h-4 fill-current" />
                <span className="text-white text-sm">{currentMovie.vote_average.toFixed(1)}</span>
              </div>
            </div>

            <h1 className="text-3xl md:text-5xl font-bold text-white mb-3 leading-tight">{currentMovie.title}</h1>

            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1 text-gray-400 text-sm">
                <Clock className="w-4 h-4" />
                <span>2h 30m</span>
              </div>
              <Badge variant="outline" className="text-gray-300 border-gray-600">
                Action
              </Badge>
            </div>

            <div className="flex gap-3">
              <Button
                className="bg-orange-500 hover:bg-orange-600 text-white px-6"
                onClick={() => onPlay?.(currentMovie)}
              >
                <Play className="w-4 h-4 mr-2" />
                Play Now
              </Button>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Add to List
              </Button>
            </div>
          </div>

          {/* Right Image */}
          <div className="hidden md:block flex-shrink-0 ml-8">
            <div className="w-64 aspect-[2/3] rounded-xl overflow-hidden shadow-2xl border border-[#ddd]/20">
              <Image
                src={getImageUrl(currentMovie.poster_path, "w500") || "/placeholder.svg"}
                alt={currentMovie.title}
                fill
                className="object-cover"
                style={{
                  filter: "saturate(1.2) drop-shadow(0 8px 16px rgba(0,0,0,0.4))",
                }}
              />
              <Badge className="absolute top-2 right-2 bg-orange-500 text-white">
                {currentMovie.vote_average.toFixed(1)}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 z-20"
        onClick={goToPrevious}
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 z-20"
        onClick={goToNext}
      >
        <ChevronRight className="w-6 h-6" />
      </Button>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
        {movies.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-2 h-2 rounded-full transition-all",
              index === currentIndex ? "bg-orange-500 w-6" : "bg-white/40",
            )}
            onClick={() => {
              setCurrentIndex(index)
              setIsAutoPlaying(false)
            }}
          />
        ))}
      </div>
    </div>
  )
}
