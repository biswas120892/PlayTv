"use client"

import type React from "react"
import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Star, Play, Heart, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getImageUrl, type Movie, type TVShow } from "@/lib/tmdb"
import { cn } from "@/lib/utils"

interface MovieCardProps {
  item: Movie | TVShow
  onPlay?: (item: Movie | TVShow) => void
  onAddToWatchlist?: (item: Movie | TVShow) => void
  className?: string
}

export function MovieCard({ item, onPlay, onAddToWatchlist, className }: MovieCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [isInWatchlist, setIsInWatchlist] = useState(false)
  const router = useRouter()

  const title = "title" in item ? item.title : item.name
  const releaseDate = "release_date" in item ? item.release_date : item.first_air_date
  const year = releaseDate ? new Date(releaseDate).getFullYear() : "N/A"
  const rating = item.vote_average.toFixed(1)
  const mediaType = "title" in item ? "Movie" : "TV"
  const isMovie = "title" in item

  const handleAddToWatchlist = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsInWatchlist(!isInWatchlist)
    onAddToWatchlist?.(item)
  }

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation()

    const watchHistory = JSON.parse(localStorage.getItem("watch-history") || "[]")
    const historyItem = {
      id: item.id,
      title: isMovie ? item.title : item.name,
      poster_path: item.poster_path,
      watchedAt: new Date().toISOString(),
      type: isMovie ? "movie" : "tv",
    }

    const filtered = watchHistory.filter((historyItem: any) => historyItem.id !== item.id)
    filtered.unshift(historyItem)
    localStorage.setItem("watch-history", JSON.stringify(filtered.slice(0, 50)))

    onPlay?.(item)
  }

  const handleCardClick = () => {
    const url = isMovie ? `/movie/${item.id}` : `/tv/${item.id}`
    router.push(url)
  }

  return (
    <div onClick={handleCardClick} className="cursor-pointer">
      <div className={cn("movie-card group relative overflow-hidden transition-all duration-300", className)}>
        <div className="aspect-[2/3] relative">
          <div className="relative h-full overflow-hidden rounded-lg">
            {!imageLoaded && <div className="absolute inset-0 bg-muted animate-pulse" />}
            <Image
              src={getImageUrl(item.poster_path, "w500") || "/placeholder.svg"}
              alt={title}
              fill
              className={cn(
                "poster-image object-cover transition-all duration-300",
                imageLoaded ? "opacity-100" : "opacity-0",
              )}
              onLoad={() => setImageLoaded(true)}
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              style={{
                filter: "saturate(1.2) drop-shadow(0 4px 8px rgba(0,0,0,0.3))",
              }}
            />

            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <div className="flex gap-2">
                <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white" onClick={handlePlay}>
                  <Play className="w-4 h-4 mr-1" />
                  Play
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 bg-transparent"
                  onClick={handleAddToWatchlist}
                >
                  <Heart className={cn("w-4 h-4", isInWatchlist && "fill-red-500 text-red-500")} />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="p-2 space-y-1">
          <h3 className="font-semibold text-foreground text-sm line-clamp-2 leading-tight">{title}</h3>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{year}</span>
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
              <span>{rating}</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className="text-xs">
              {mediaType}
            </Badge>
            {mediaType === "Movie" && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>120m</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
