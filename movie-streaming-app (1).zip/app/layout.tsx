import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "StreamFlix - Watch Movies & TV Shows Online Free | HD Streaming",
  description:
    "Watch thousands of movies and TV shows online for free in HD quality. Stream the latest releases, popular series, and classic films without subscription. No ads, no registration required.",
  keywords: "free movies, watch online, TV shows, streaming, HD movies, free streaming, online cinema, watch series",
  authors: [{ name: "StreamFlix" }],
  creator: "StreamFlix",
  publisher: "StreamFlix",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://streamflix.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "StreamFlix - Watch Movies & TV Shows Online Free",
    description: "Stream thousands of movies and TV shows for free in HD quality. No subscription required.",
    url: "https://streamflix.com",
    siteName: "StreamFlix",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "StreamFlix - Free Movie Streaming",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "StreamFlix - Watch Movies & TV Shows Online Free",
    description: "Stream thousands of movies and TV shows for free in HD quality. No subscription required.",
    images: ["/twitter-image.jpg"],
    creator: "@streamflix",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
    yandex: "your-yandex-verification-code",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "StreamFlix",
              description: "Watch thousands of movies and TV shows online for free in HD quality",
              url: "https://streamflix.com",
              potentialAction: {
                "@type": "SearchAction",
                target: "https://streamflix.com/search?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
              publisher: {
                "@type": "Organization",
                name: "StreamFlix",
                logo: {
                  "@type": "ImageObject",
                  url: "https://streamflix.com/logo.png",
                },
              },
            }),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "VideoObject",
              name: "Free Movie Streaming",
              description: "Stream movies and TV shows for free",
              thumbnailUrl: "https://streamflix.com/thumbnail.jpg",
              uploadDate: "2024-01-01",
              contentUrl: "https://streamflix.com",
              embedUrl: "https://streamflix.com",
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
