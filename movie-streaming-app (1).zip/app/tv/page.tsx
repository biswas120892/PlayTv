"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/sidebar"
import { BottomNav } from "@/components/bottom-nav"
import { SearchBar } from "@/components/search-bar"
import { MovieCard } from "@/components/movie-card"
import { VideoPlayer } from "@/components/video-player"
import { BackToTop } from "@/components/back-to-top"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { tmdbApi, type Movie, type TVShow } from "@/lib/tmdb"
import { User, Film } from "lucide-react"

const filterTabs = [
  { id: "popular", label: "Popular" },
  { id: "top", label: "Top" },
  { id: "airing", label: "Airing" },
  { id: "genre", label: "Genre" },
  { id: "language", label: "Language" },
]

const languages = [
  { code: "all", name: "All Languages" },
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
]

export default function TVShowsPage() {
  const router = useRouter()
  const [tvShows, setTVShows] = useState<TVShow[]>([])
  const [genres, setGenres] = useState<{ id: number; name: string }[]>([])
  const [activeTab, setActiveTab] = useState("popular")
  const [selectedGenre, setSelectedGenre] = useState<string>("all")
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all")
  const [selectedItem, setSelectedItem] = useState<Movie | TVShow | null>(null)
  const [isPlayerOpen, setIsPlayerOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadGenres()
    loadTVShows()
  }, [])

  useEffect(() => {
    loadTVShows()
  }, [activeTab, selectedGenre, selectedLanguage])

  const loadGenres = async () => {
    try {
      const response = await tmdbApi.getGenres("tv")
      setGenres(response.genres || [])
    } catch (error) {
      console.error("Error loading genres:", error)
    }
  }

  const loadTVShows = async () => {
    setIsLoading(true)
    try {
      let response
      switch (activeTab) {
        case "popular":
          response = await tmdbApi.getPopular("tv")
          break
        case "top":
          response = await tmdbApi.getTopRated("tv")
          break
        case "airing":
          response = await tmdbApi.getTrending("tv", "week")
          break
        case "genre":
          if (selectedGenre !== "all") {
            response = await tmdbApi.getByGenre(Number.parseInt(selectedGenre), "tv")
          } else {
            response = await tmdbApi.getPopular("tv")
          }
          break
        case "language":
          if (selectedLanguage !== "all") {
            const url = `https://api.themoviedb.org/3/discover/tv?api_key=7bffed716d50c95ed1c4790cfab4866a&with_original_language=${selectedLanguage}&sort_by=popularity.desc`
            const res = await fetch(url)
            response = await res.json()
          } else {
            response = await tmdbApi.getPopular("tv")
          }
          break
        default:
          response = await tmdbApi.getPopular("tv")
      }

      setTVShows(response.results || [])
    } catch (error) {
      console.error("Error loading TV shows:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handlePlay = (item: Movie | TVShow) => {
    setSelectedItem(item)
    setIsPlayerOpen(true)
  }

  const handleAddToWatchlist = (item: Movie | TVShow) => {
    const watchlist = JSON.parse(localStorage.getItem("watchlist") || "[]")
    const exists = watchlist.find((w: any) => w.id === item.id)

    if (!exists) {
      watchlist.push({ ...item, addedAt: new Date().toISOString() })
      localStorage.setItem("watchlist", JSON.stringify(watchlist))
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Sidebar />

      <main className="md:ml-16 pb-20 md:pb-8">
        {/* Header */}
        <header className="flex items-center justify-between p-4 md:p-6 border-b border-border">
          <div className="flex items-center gap-4 flex-1">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                <Film className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold hidden md:block">StreamFlix</span>
            </div>
            <SearchBar onResultClick={handlePlay} />
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => router.push("/profile")}
            >
              <User className="w-5 h-5" />
            </Button>
          </div>
        </header>

        {/* Title and Filter Tabs */}
        <div className="p-4 md:p-6">
          <h1 className="text-2xl font-bold mb-4">Browse TV shows</h1>

          <div className="flex flex-wrap gap-2 mb-4">
            {filterTabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab(tab.id)}
                className={
                  activeTab === tab.id
                    ? "bg-orange-500 hover:bg-orange-600 text-white"
                    : "border-border text-muted-foreground hover:bg-accent"
                }
              >
                {tab.label}
              </Button>
            ))}
          </div>

          {activeTab === "genre" && (
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select Genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Genres</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre.id} value={genre.id.toString()}>
                    {genre.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          {activeTab === "language" && (
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* TV Shows Grid */}
        <div className="p-4 md:p-6">
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="aspect-[2/3] bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {tvShows.map((show) => (
                <MovieCard key={show.id} item={show} onPlay={handlePlay} onAddToWatchlist={handleAddToWatchlist} />
              ))}
            </div>
          )}
        </div>
      </main>

      <BottomNav />
      <BackToTop />

      <VideoPlayer isOpen={isPlayerOpen} onClose={() => setIsPlayerOpen(false)} item={selectedItem} />
    </div>
  )
}
